Elementary Sorts:

Given an Integer array sort the array using insertion and selection sort

You were given a Solution file contains two methods sortInsertion and sortSelection which accepts an integer array as parameter.

sortInsertion – Sort the array passed as parameter by using insertion sort and return the array.

SortSelection - Sort the array passed as parameter by using selection sort and return the array.
