class Solution{
	public int[] sortInsertion(int[] arr){
		// fill you code Here
		return null;
	}
	public int[] sortSelection(int[] arr){
		// fill you code Here
		return null;
	}
}